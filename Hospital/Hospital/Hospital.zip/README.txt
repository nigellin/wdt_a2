Group Members:
	Kiriti Kunapareddy - s3382421
		UI Desing/Implementation
		Backend Development

	Nanxing Lin (Nigel) - s3287015
		UI Design/Implementation
		Frontend & Backend Development
		Database design

	Chih-Hao Fang (Chris) - s3362174
		Backend Development
	
Assumptions :
	We have used the search function for the filter function as they both do the job correct


References:

Logo image:
	https://www.google.com.au/search?q=icare&source=lnms&tbm=isch&sa=X&ei=XM3xUr-YFoqIkwWNhoCQCA&ved=0CAcQ_AUoAQ&biw=1366&bih=667#facrc=_&imgdii=_&imgrc=h2to82zBVubUvM%253A%3BQszthOyjIXtjkM%3Bhttp%253A%252F%252Fupload.wikimedia.org%252Fwikipedia%252Fcommons%252Fa%252Fa8%252FLogo_icare_png.png%3Bhttp%253A%252F%252Fcommons.wikimedia.org%252Fwiki%252FFile%253ALogo_icare_png.png%3B945%3B591

Bootstrap Framework/:
	http://getbootstrap.com/getting-started/

Credit Card Validation:

	http://jqueryvalidation.org/creditcard-method/
	http://jquery.bassistance.de/validate/jquery.validate.js


DISCLAIMER
	All images and source code have been used for education purposes only and in no way are intended to infringe copyright laws. 
	
